import os
import zipfile
import tempfile
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, HttpResponseForbidden
from .models import Content, Assignment, Submission, Grade
from .forms import ContentForm, AssignmentForm, SubmissionForm, GradeForm
from rooms.models import Room, RoomMembership
from notifications.models import Notification


@login_required
def upload_content(request, room_id):
    """Teacher uploads course content."""
    room = get_object_or_404(Room, pk=room_id)
    if room.teacher != request.user:
        return HttpResponseForbidden()

    if request.method == 'POST':
        form = ContentForm(room, request.POST, request.FILES)
        if form.is_valid():
            content = form.save(commit=False)
            content.room = room
            content.save()
            messages.success(request, f'Content "{content.title}" uploaded!')
            # Notify students
            members = room.memberships.filter(status='approved')
            for m in members:
                Notification.objects.create(
                    user=m.student,
                    notification_type='announcement',
                    title='New Content',
                    message=f'New {content.get_content_type_display()} in {room.name}: {content.title}',
                    link=f'/rooms/{room.pk}/',
                )
            return redirect('room_detail', room_id=room.pk)
    else:
        form = ContentForm(room)
    return render(request, 'content/upload_content.html', {'form': form, 'room': room})


@login_required
def create_assignment(request, room_id):
    """Teacher creates an assignment."""
    room = get_object_or_404(Room, pk=room_id)
    if room.teacher != request.user:
        return HttpResponseForbidden()

    if request.method == 'POST':
        form = AssignmentForm(room, request.POST, request.FILES)
        if form.is_valid():
            assignment = form.save(commit=False)
            assignment.room = room
            assignment.save()
            messages.success(request, f'Assignment "{assignment.title}" created!')
            # Notify students
            members = room.memberships.filter(status='approved')
            for m in members:
                Notification.objects.create(
                    user=m.student,
                    notification_type='assignment',
                    title='New Assignment',
                    message=f'New assignment in {room.name}: {assignment.title}',
                    link=f'/rooms/{room.pk}/assignments/{assignment.pk}/',
                )
            return redirect('room_detail', room_id=room.pk)
    else:
        form = AssignmentForm(room)
    return render(request, 'content/create_assignment.html', {'form': form, 'room': room})


@login_required
def assignment_detail(request, room_id, assignment_id):
    """View assignment details + submit work (student) / view submissions (teacher)."""
    room = get_object_or_404(Room, pk=room_id)
    assignment = get_object_or_404(Assignment, pk=assignment_id, room=room)
    user = request.user
    is_teacher = room.teacher == user

    if not is_teacher:
        is_member = RoomMembership.objects.filter(room=room, student=user, status='approved').exists()
        if not is_member:
            return HttpResponseForbidden()

    context = {
        'room': room,
        'assignment': assignment,
        'is_teacher': is_teacher,
    }

    if is_teacher:
        context['submissions'] = assignment.submissions.select_related('student', 'grade')
        return render(request, 'content/assignment_teacher.html', context)
    else:
        # Check if student already submitted
        try:
            submission = Submission.objects.get(assignment=assignment, student=user)
            context['submission'] = submission
        except Submission.DoesNotExist:
            submission = None

        if request.method == 'POST' and not submission:
            form = SubmissionForm(request.POST, request.FILES)
            if form.is_valid():
                sub = form.save(commit=False)
                sub.assignment = assignment
                sub.student = user
                sub.save()
                messages.success(request, 'Work submitted successfully!')
                # Notify teacher
                Notification.objects.create(
                    user=room.teacher,
                    notification_type='submission',
                    title='New Submission',
                    message=f'{user.get_full_name() or user.username} submitted {assignment.title}',
                    link=f'/rooms/{room.pk}/assignments/{assignment.pk}/',
                )
                return redirect('assignment_detail', room_id=room.pk, assignment_id=assignment.pk)
        else:
            form = SubmissionForm()

        context['form'] = form
        return render(request, 'content/assignment_student.html', context)


@login_required
def grade_submission(request, room_id, assignment_id, submission_id):
    """Teacher grades a submission."""
    room = get_object_or_404(Room, pk=room_id)
    if room.teacher != request.user:
        return HttpResponseForbidden()

    submission = get_object_or_404(Submission, pk=submission_id, assignment__room=room)

    if request.method == 'POST':
        form = GradeForm(request.POST)
        if form.is_valid():
            grade, created = Grade.objects.update_or_create(
                submission=submission,
                defaults={
                    'score': form.cleaned_data['score'],
                    'feedback': form.cleaned_data['feedback'],
                    'graded_by': request.user,
                }
            )
            submission.status = 'graded'
            submission.save()
            messages.success(request, f'Grade saved for {submission.student.username}!')
            # Notify student
            Notification.objects.create(
                user=submission.student,
                notification_type='grade',
                title='Grade Posted',
                message=f'Your submission for {submission.assignment.title} has been graded: {grade.score}/{submission.assignment.max_grade}',
                link=f'/rooms/{room.pk}/assignments/{submission.assignment.pk}/',
            )
            return redirect('assignment_detail', room_id=room.pk, assignment_id=assignment_id)
    else:
        initial = {}
        try:
            existing = submission.grade
            initial = {'score': existing.score, 'feedback': existing.feedback}
        except Grade.DoesNotExist:
            pass
        form = GradeForm(initial=initial)

    return render(request, 'content/grade_submission.html', {
        'form': form, 'room': room, 'submission': submission,
    })


@login_required
def download_all_submissions(request, room_id, assignment_id):
    """Teacher downloads all submissions as ZIP."""
    room = get_object_or_404(Room, pk=room_id)
    if room.teacher != request.user:
        return HttpResponseForbidden()

    assignment = get_object_or_404(Assignment, pk=assignment_id, room=room)
    submissions = assignment.submissions.all()

    if not submissions.exists():
        messages.info(request, 'No submissions to download.')
        return redirect('assignment_detail', room_id=room.pk, assignment_id=assignment.pk)

    temp = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
    with zipfile.ZipFile(temp, 'w') as zf:
        for sub in submissions:
            if sub.file:
                filename = f"{sub.student.username}_{os.path.basename(sub.file.name)}"
                zf.write(sub.file.path, filename)
    temp.close()

    with open(temp.name, 'rb') as f:
        response = HttpResponse(f.read(), content_type='application/zip')
        response['Content-Disposition'] = f'attachment; filename="{assignment.title}_submissions.zip"'

    os.unlink(temp.name)
    return response


@login_required
def delete_content(request, room_id, content_id):
    """Teacher deletes content."""
    room = get_object_or_404(Room, pk=room_id)
    if room.teacher != request.user:
        return HttpResponseForbidden()

    content = get_object_or_404(Content, pk=content_id, room=room)
    content.delete()
    messages.success(request, 'Content deleted.')
    return redirect('room_detail', room_id=room.pk)
