from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django.shortcuts import get_object_or_404
from .models import Section, Content, Assignment, Submission, Grade, SubmissionFile
from .serializers import (SectionSerializer, ContentSerializer,
                          AssignmentSerializer, SubmissionSerializer, GradeSerializer)
from rooms.models import Room, RoomMembership
from notifications.models import Notification
from accounts.emails import notify_room_members, notify_teacher


class SectionViewSet(viewsets.ModelViewSet):
    serializer_class = SectionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        room_id = self.request.query_params.get('room')
        if room_id:
            return Section.objects.filter(room_id=room_id)
        return Section.objects.none()

    def perform_create(self, serializer):
        room = get_object_or_404(Room, pk=self.request.data.get('room'))
        max_order = room.sections.count()
        serializer.save(room=room, order=max_order)


class ContentViewSet(viewsets.ModelViewSet):
    serializer_class = ContentSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_queryset(self):
        room_id = self.request.query_params.get('room')
        if room_id:
            return Content.objects.filter(room_id=room_id)
        return Content.objects.none()

    def perform_create(self, serializer):
        content = serializer.save()
        room = content.room
        # Notify students by email + in-app
        members = RoomMembership.objects.filter(room=room, status='approved')
        for m in members:
            Notification.objects.create(
                user=m.student,
                notification_type='content',
                title='Nouveau contenu',
                message=f'Nouveau contenu "{content.title}" dans {room.name}',
                link=f'/rooms/{room.pk}/',
            )
        notify_room_members(
            room,
            f'Nouveau contenu dans {room.name}',
            f'Le professeur a publié "{content.title}" dans {room.name}.',
        )


class AssignmentViewSet(viewsets.ModelViewSet):
    serializer_class = AssignmentSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_queryset(self):
        room_id = self.request.query_params.get('room')
        if room_id:
            return Assignment.objects.filter(room_id=room_id)
        return Assignment.objects.none()

    def perform_create(self, serializer):
        assignment = serializer.save()
        room = assignment.room
        members = RoomMembership.objects.filter(room=room, status='approved')
        for m in members:
            Notification.objects.create(
                user=m.student,
                notification_type='assignment',
                title='Nouveau devoir',
                message=f'Nouveau devoir "{assignment.title}" dans {room.name}',
                link=f'/rooms/{room.pk}/',
            )
        notify_room_members(
            room,
            f'Nouveau devoir dans {room.name}',
            f'Le professeur a publié le devoir "{assignment.title}" dans {room.name}.',
        )


class SubmissionViewSet(viewsets.ModelViewSet):
    serializer_class = SubmissionSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_queryset(self):
        assignment_id = self.request.query_params.get('assignment')
        if assignment_id:
            user = self.request.user
            qs = Submission.objects.filter(assignment_id=assignment_id)
            if user.is_student:
                qs = qs.filter(student=user)
            return qs.select_related('student', 'grade')
        return Submission.objects.none()

    def perform_create(self, serializer):
        assignment = get_object_or_404(Assignment, pk=self.request.data.get('assignment'))
        submission = serializer.save(student=self.request.user, assignment=assignment)
        
        # Handle multiple file uploads
        files = self.request.FILES.getlist('files')
        for f in files:
            SubmissionFile.objects.create(submission=submission, file=f)
            
        Notification.objects.create(
            user=assignment.room.teacher,
            notification_type='submission',
            title='Nouvelle soumission',
            message=f'{self.request.user.get_full_name()} a soumis "{assignment.title}"',
            link=f'/rooms/{assignment.room.pk}/',
        )
        notify_teacher(
            assignment.room,
            'Nouvelle soumission',
            f'{self.request.user.get_full_name()} a soumis le devoir "{assignment.title}".',
        )

    def grade(self, request, pk=None):
        """Grade a submission (teacher only)."""
        submission = self.get_object()
        score = request.data.get('score')
        feedback = request.data.get('feedback', '')
        grade, _ = Grade.objects.update_or_create(
            submission=submission,
            defaults={'score': score, 'feedback': feedback, 'graded_by': request.user}
        )
        submission.status = 'graded'
        submission.save()
        Notification.objects.create(
            user=submission.student,
            notification_type='grade',
            title='Note publiée',
            message=f'Vous avez reçu {score}/{submission.assignment.max_grade} pour "{submission.assignment.title}"',
            link=f'/rooms/{submission.assignment.room.pk}/',
        )
        return Response(GradeSerializer(grade).data)
