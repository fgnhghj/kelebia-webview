from django import forms
from .models import Content, Assignment, Submission


class ContentForm(forms.ModelForm):
    """Form for uploading course content."""
    class Meta:
        model = Content
        fields = ['title', 'description', 'content_type', 'file', 'link', 'section', 'is_pinned']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, room=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if room:
            self.fields['section'].queryset = room.sections.all()
            self.fields['section'].required = False


class AssignmentForm(forms.ModelForm):
    """Form for creating an assignment."""
    class Meta:
        model = Assignment
        fields = ['title', 'description', 'file', 'section', 'deadline', 'max_grade', 'allow_late']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
            'deadline': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

    def __init__(self, room=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if room:
            self.fields['section'].queryset = room.sections.all()
            self.fields['section'].required = False


class SubmissionForm(forms.ModelForm):
    """Form for student to submit work."""
    class Meta:
        model = Submission
        fields = ['file', 'comment']
        widgets = {
            'comment': forms.Textarea(attrs={'rows': 2, 'placeholder': 'Optional comment...'}),
        }


class GradeForm(forms.Form):
    """Form for grading a submission."""
    score = forms.DecimalField(max_digits=5, decimal_places=2)
    feedback = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), required=False)
