from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Announcement, Comment
from .serializers import AnnouncementSerializer, AnnouncementListSerializer, CommentSerializer
from rooms.models import Room, RoomMembership
from notifications.models import Notification


class AnnouncementViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.action == 'list':
            return AnnouncementListSerializer
        return AnnouncementSerializer

    def get_queryset(self):
        room_id = self.request.query_params.get('room')
        if room_id:
            return Announcement.objects.filter(room_id=room_id).select_related('author')
        return Announcement.objects.none()

    def perform_create(self, serializer):
        announcement = serializer.save(author=self.request.user)
        room = announcement.room
        members = RoomMembership.objects.filter(room=room, status='approved')
        for m in members:
            Notification.objects.create(
                user=m.student,
                notification_type='announcement',
                title='New Announcement',
                message=f'{announcement.title} in {room.name}',
                link=f'/rooms/{room.pk}/',
            )


class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        announcement_id = self.request.query_params.get('announcement')
        if announcement_id:
            return Comment.objects.filter(announcement_id=announcement_id).select_related('author')
        return Comment.objects.none()

    def perform_create(self, serializer):
        announcement = Announcement.objects.get(pk=self.request.data.get('announcement'))
        comment = serializer.save(author=self.request.user, announcement=announcement)
        if announcement.author != self.request.user:
            Notification.objects.create(
                user=announcement.author,
                notification_type='comment',
                title='New Comment',
                message=f'{self.request.user.get_full_name()} commented on "{announcement.title}"',
                link=f'/rooms/{announcement.room.pk}/',
            )
