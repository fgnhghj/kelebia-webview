"""Email utilities for Kelebia Classroom."""
from django.core.mail import send_mail
from django.conf import settings


def send_verification_email(user):
    """Send a 6-digit verification code to the user's email."""
    code = user.generate_verification_code()
    send_mail(
        subject='Kelebia Classroom — Code de vérification',
        message=(
            f'Bonjour {user.first_name},\n\n'
            f'Votre code de vérification est : {code}\n\n'
            f'Ce code expire dans 15 minutes.\n\n'
            f'— Kelebia Classroom'
        ),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        fail_silently=True,
    )


def send_notification_email(user, subject, message):
    """Send a generic notification email to a user."""
    send_mail(
        subject=f'Kelebia Classroom — {subject}',
        message=(
            f'Bonjour {user.first_name},\n\n'
            f'{message}\n\n'
            f'Connectez-vous : {settings.SITE_URL}\n\n'
            f'— Kelebia Classroom'
        ),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        fail_silently=True,
    )


def notify_room_members(room, subject, message, exclude_user=None):
    """Send an email to all approved members of a room."""
    from rooms.models import RoomMembership
    memberships = RoomMembership.objects.filter(
        room=room, status='approved'
    ).select_related('student')
    for m in memberships:
        if exclude_user and m.student == exclude_user:
            continue
        send_notification_email(m.student, subject, message)


def notify_teacher(room, subject, message):
    """Send an email to the teacher of a room."""
    send_notification_email(room.teacher, subject, message)
