from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .forms import SignUpForm, LoginForm, UserProfileForm
from .models import User
from notifications.models import Notification


def landing_page(request):
    """Landing page for unauthenticated users."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'landing.html')


def signup_view(request):
    """User registration."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome to EduRoom, {user.first_name}!')
            return redirect('dashboard')
    else:
        form = SignUpForm()
    return render(request, 'auth/signup.html', {'form': form})


def login_view(request):
    """User login."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'],
            )
            if user is not None:
                login(request, user)
                next_url = request.GET.get('next', 'dashboard')
                return redirect(next_url)
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'auth/login.html', {'form': form})


def logout_view(request):
    """Log out the user."""
    logout(request)
    return redirect('landing')


@login_required
def dashboard_view(request):
    """Main dashboard — different for teacher/student."""
    user = request.user
    if user.is_teacher:
        rooms = user.rooms_teaching.filter(is_active=True)
        return render(request, 'dashboard/teacher_dashboard.html', {
            'rooms': rooms,
        })
    else:
        memberships = user.room_memberships.filter(status='approved').select_related('room', 'room__teacher')
        return render(request, 'dashboard/student_dashboard.html', {
            'memberships': memberships,
        })


@login_required
def profile_view(request):
    """User profile page."""
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=request.user)
    return render(request, 'auth/profile.html', {'form': form})


@login_required
def notifications_view(request):
    """Notifications page."""
    notifs = Notification.objects.filter(user=request.user)
    unread_count = notifs.filter(is_read=False).count()
    return render(request, 'notifications.html', {
        'notifications': notifs[:50],
        'unread_count': unread_count,
    })


@login_required
def mark_notification_read(request, pk):
    """Mark a notification as read."""
    notif = get_object_or_404(Notification, pk=pk, user=request.user)
    notif.is_read = True
    notif.save()
    if notif.link:
        return redirect(notif.link)
    return redirect('notifications')


@login_required
def mark_all_read(request):
    """Mark all notifications as read."""
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return redirect('notifications')


@login_required
def get_unread_count(request):
    """API: Get unread notification count."""
    count = Notification.objects.filter(user=request.user, is_read=False).count()
    return JsonResponse({'count': count})
