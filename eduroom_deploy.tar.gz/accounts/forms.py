from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User


class SignUpForm(UserCreationForm):
    """Registration form with role selection."""
    role = forms.ChoiceField(choices=User.ROLE_CHOICES, widget=forms.RadioSelect)
    first_name = forms.CharField(max_length=50, required=True)
    last_name = forms.CharField(max_length=50, required=True)
    email = forms.EmailField(required=True)
    institution = forms.CharField(max_length=200, required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'role', 'institution', 'password1', 'password2']


class UserProfileForm(forms.ModelForm):
    """Form for editing user profile."""
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'bio', 'institution', 'avatar']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3}),
        }


class LoginForm(forms.Form):
    """Login form."""
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)
