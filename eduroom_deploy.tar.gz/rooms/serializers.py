from rest_framework import serializers
from .models import Room, RoomMembership
from accounts.serializers import UserSerializer


class RoomSerializer(serializers.ModelSerializer):
    teacher = UserSerializer(read_only=True)
    student_count = serializers.IntegerField(read_only=True)
    is_member = serializers.SerializerMethodField()

    class Meta:
        model = Room
        fields = ['id', 'name', 'description', 'subject', 'invite_code',
                  'color_theme', 'cover_image', 'is_active', 'teacher',
                  'student_count', 'is_member', 'created_at', 'updated_at']
        read_only_fields = ['id', 'invite_code', 'teacher', 'created_at', 'updated_at']

    def get_is_member(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            if obj.teacher == request.user:
                return True
            return RoomMembership.objects.filter(
                room=obj, student=request.user, status='approved'
            ).exists()
        return False


class RoomCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Room
        fields = ['name', 'description', 'subject', 'color_theme', 'cover_image']


class RoomMembershipSerializer(serializers.ModelSerializer):
    student = UserSerializer(read_only=True)

    class Meta:
        model = RoomMembership
        fields = ['id', 'student', 'status', 'joined_at']
        read_only_fields = ['id', 'student', 'joined_at']
