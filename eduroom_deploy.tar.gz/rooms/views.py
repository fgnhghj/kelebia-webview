from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseForbidden
from .models import Room, RoomMembership
from .forms import RoomForm, JoinRoomForm
from content.models import Section, Content, Assignment, Submission
from announcements.models import Announcement
from notifications.models import Notification


def teacher_required(view_func):
    """Decorator: restrict to teachers only."""
    def wrapper(request, *args, **kwargs):
        if not request.user.is_teacher:
            messages.error(request, 'Only teachers can access this page.')
            return redirect('dashboard')
        return view_func(request, *args, **kwargs)
    return wrapper


def room_teacher_required(view_func):
    """Decorator: restrict to the room's teacher only."""
    def wrapper(request, room_id, *args, **kwargs):
        room = get_object_or_404(Room, pk=room_id)
        if room.teacher != request.user:
            return HttpResponseForbidden('You are not the teacher of this room.')
        request.room = room
        return view_func(request, room_id, *args, **kwargs)
    return wrapper


@login_required
@teacher_required
def create_room(request):
    """Create a new classroom room."""
    if request.method == 'POST':
        form = RoomForm(request.POST, request.FILES)
        if form.is_valid():
            room = form.save(commit=False)
            room.teacher = request.user
            room.save()
            # Create a default section
            Section.objects.create(room=room, title='General', order=0)
            messages.success(request, f'Room "{room.name}" created!')
            return redirect('room_detail', room_id=room.pk)
    else:
        form = RoomForm()
    return render(request, 'rooms/create_room.html', {'form': form})


@login_required
@teacher_required
@room_teacher_required
def edit_room(request, room_id):
    """Edit room details."""
    room = request.room
    if request.method == 'POST':
        form = RoomForm(request.POST, request.FILES, instance=room)
        if form.is_valid():
            form.save()
            messages.success(request, 'Room updated!')
            return redirect('room_detail', room_id=room.pk)
    else:
        form = RoomForm(instance=room)
    return render(request, 'rooms/edit_room.html', {'form': form, 'room': room})


@login_required
def room_detail(request, room_id):
    """View a room — teacher sees management, student sees content."""
    room = get_object_or_404(Room, pk=room_id)
    user = request.user

    # Check access
    is_teacher = room.teacher == user
    is_member = False
    if user.is_student:
        is_member = RoomMembership.objects.filter(room=room, student=user, status='approved').exists()

    if not is_teacher and not is_member:
        messages.error(request, 'You do not have access to this room.')
        return redirect('dashboard')

    sections = room.sections.prefetch_related('contents', 'assignments')
    announcements = room.announcements.all()[:10]
    assignments = room.assignments.all()

    context = {
        'room': room,
        'sections': sections,
        'announcements': announcements,
        'assignments': assignments,
        'is_teacher': is_teacher,
    }

    if is_teacher:
        context['members'] = room.memberships.filter(status='approved').select_related('student')
        context['pending'] = room.memberships.filter(status='pending').select_related('student')
        return render(request, 'rooms/room_teacher.html', context)
    else:
        # Get student's submissions
        context['my_submissions'] = Submission.objects.filter(
            student=user, assignment__room=room
        ).select_related('assignment', 'grade')
        return render(request, 'rooms/room_student.html', context)


@login_required
def join_room(request):
    """Join a room via invite code."""
    if request.method == 'POST':
        form = JoinRoomForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['invite_code'].upper()
            try:
                room = Room.objects.get(invite_code=code, is_active=True)
            except Room.DoesNotExist:
                messages.error(request, 'Invalid invite code. Please try again.')
                return redirect('join_room')

            if room.teacher == request.user:
                messages.info(request, 'You are the teacher of this room.')
                return redirect('room_detail', room_id=room.pk)

            membership, created = RoomMembership.objects.get_or_create(
                room=room,
                student=request.user,
                defaults={'status': 'approved'}
            )
            if created:
                messages.success(request, f'You joined "{room.name}"!')
                # Notify teacher
                Notification.objects.create(
                    user=room.teacher,
                    notification_type='room',
                    title='New Student Joined',
                    message=f'{request.user.get_full_name() or request.user.username} joined {room.name}',
                    link=f'/rooms/{room.pk}/',
                )
            else:
                messages.info(request, 'You are already a member of this room.')
            return redirect('room_detail', room_id=room.pk)
    else:
        form = JoinRoomForm()
    return render(request, 'rooms/join_room.html', {'form': form})


@login_required
@teacher_required
@room_teacher_required
def manage_members(request, room_id):
    """Manage room members (approve/remove)."""
    room = request.room
    if request.method == 'POST':
        action = request.POST.get('action')
        member_id = request.POST.get('member_id')
        membership = get_object_or_404(RoomMembership, pk=member_id, room=room)

        if action == 'approve':
            membership.status = 'approved'
            membership.save()
            messages.success(request, f'{membership.student.username} approved.')
        elif action == 'remove':
            membership.status = 'removed'
            membership.save()
            messages.success(request, f'{membership.student.username} removed.')

    return redirect('room_detail', room_id=room.pk)


@login_required
@teacher_required
@room_teacher_required
def add_section(request, room_id):
    """Add a new section to the room."""
    room = request.room
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        if title:
            max_order = room.sections.count()
            Section.objects.create(room=room, title=title, order=max_order)
            messages.success(request, f'Section "{title}" added!')
    return redirect('room_detail', room_id=room.pk)
