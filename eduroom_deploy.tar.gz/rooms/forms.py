from django import forms
from .models import Room


class RoomForm(forms.ModelForm):
    """Form for creating/editing a room."""
    class Meta:
        model = Room
        fields = ['name', 'description', 'subject', 'color_theme', 'cover_image']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
            'color_theme': forms.RadioSelect,
        }


class JoinRoomForm(forms.Form):
    """Form for joining a room by invite code."""
    invite_code = forms.CharField(max_length=8, min_length=8)
