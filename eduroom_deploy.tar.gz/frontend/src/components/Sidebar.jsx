import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { useEffect, useState } from 'react';
import { notificationsAPI } from '../api';
import { FiPieChart, FiBell, FiUser, FiMoon, FiSun, FiLogOut } from 'react-icons/fi';

export default function Sidebar() {
    const { user, logout } = useAuth();
    const [unread, setUnread] = useState(0);

    useEffect(() => {
        notificationsAPI.unreadCount().then(r => setUnread(r.data.count)).catch(() => { });
    }, []);

    const toggleTheme = () => {
        const currentTheme = document.documentElement.getAttribute('data-theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
        const next = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
    };

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

    return (
        <aside className="sidebar">
            <div className="sidebar-header">
                <Link to="/dashboard" className="sidebar-brand">
                    <div className="logo">K</div>
                    <h1>Kelebia<small>par Aymen HM</small></h1>
                </Link>
            </div>

            <nav className="sidebar-nav">
                <div className="nav-section">
                    <div className="nav-section-title">Menu</div>
                    <Link to="/dashboard" className="nav-item">
                        <span className="icon"><FiPieChart /></span> Tableau de bord
                    </Link>
                    <Link to="/notifications" className="nav-item">
                        <span className="icon"><FiBell /></span> Notifications
                        {unread > 0 && <span className="badge">{unread}</span>}
                    </Link>
                    <Link to="/profile" className="nav-item">
                        <span className="icon"><FiUser /></span> Profil
                    </Link>
                </div>

                <div className="nav-section">
                    <div className="nav-section-title">Paramètres</div>
                    <button className="nav-item" onClick={toggleTheme}>
                        <span className="icon">{isDark ? <FiSun /> : <FiMoon />}</span> Changer le thème
                    </button>
                    <button className="nav-item" onClick={logout} style={{ color: 'var(--danger)' }}>
                        <span className="icon"><FiLogOut /></span> Déconnexion
                    </button>
                </div>
            </nav>

            <div className="sidebar-footer">
                <Link to="/profile" className="user-card" style={{ textDecoration: 'none' }}>
                    <div className="avatar">
                        {(user?.first_name?.[0] || 'U').toUpperCase()}
                    </div>
                    <div className="user-info">
                        <div className="name">{user?.full_name || user?.username}</div>
                        <div className="role">{user?.role === 'teacher' ? 'Professeur' : 'Étudiant'}</div>
                    </div>
                </Link>
            </div>
        </aside>
    );
}
