import { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { FiMonitor, FiBookOpen } from 'react-icons/fi';

function getPasswordStrength(pw) {
    let score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
    if (/\d/.test(pw)) score++;
    if (/[^a-zA-Z0-9]/.test(pw)) score++;
    if (score <= 1) return { level: 'weak', pct: 25, color: 'strength-weak', label: 'Faible' };
    if (score <= 2) return { level: 'fair', pct: 50, color: 'strength-fair', label: 'Moyen' };
    if (score <= 3) return { level: 'good', pct: 75, color: 'strength-good', label: 'Bon' };
    return { level: 'strong', pct: 100, color: 'strength-strong', label: 'Fort' };
}

export default function Signup() {
    const { signup } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({
        first_name: '', last_name: '', email: '', password: '', confirmPassword: '', role: 'student'
    });
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});

    const strength = useMemo(() => getPasswordStrength(form.password), [form.password]);
    const passwordsMatch = form.password && form.confirmPassword && form.password === form.confirmPassword;
    const passwordsMismatch = form.confirmPassword && form.password !== form.confirmPassword;

    const update = (field, value) => {
        setForm(prev => ({ ...prev, [field]: value }));
        setErrors(prev => ({ ...prev, [field]: '' }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({});

        if (form.password !== form.confirmPassword) {
            setErrors({ confirmPassword: 'Les mots de passe ne correspondent pas.' });
            return;
        }
        if (form.password.length < 8) {
            setErrors({ password: 'Le mot de passe doit comporter au moins 8 caractères.' });
            return;
        }

        setLoading(true);
        try {
            const result = await signup({
                first_name: form.first_name,
                last_name: form.last_name,
                email: form.email,
                password: form.password,
                role: form.role,
            });
            toast.success('Compte créé ! Vérifiez votre email.');
            navigate('/verify-email');
        } catch (err) {
            const data = err.response?.data;
            if (data) {
                const newErrors = {};
                Object.entries(data).forEach(([key, val]) => {
                    newErrors[key] = Array.isArray(val) ? val[0] : val;
                });
                setErrors(newErrors);
            } else {
                toast.error('Une erreur est survenue. Veuillez réessayer.');
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-page">
            <motion.div
                className="auth-card card"
                style={{ width: '100%', maxWidth: 440, margin: '64px auto', padding: 40 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            >
                <div style={{ textAlign: 'center', marginBottom: 32 }}>
                    <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
                        <div className="logo" style={{
                            width: 32, height: 32,
                            background: 'var(--text-primary)', color: 'var(--bg-primary)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            borderRadius: 6, fontWeight: 500, fontFamily: 'var(--font-serif)'
                        }}>K</div>
                        <h2 style={{ fontSize: 20, fontFamily: 'var(--font-serif)' }}>Kelebia Classroom</h2>
                    </Link>
                    <h1 style={{ fontSize: 28 }}>Créer un compte</h1>
                    <p style={{ color: 'var(--text-secondary)', marginTop: 8 }}>Rejoignez la plateforme conçue pour la concentration</p>
                </div>

                <form onSubmit={handleSubmit}>
                    {/* Role Picker */}
                    <div className="form-group">
                        <label className="form-label">Je suis...</label>
                        <div style={{ display: 'flex', gap: 12 }}>
                            <div
                                style={{
                                    flex: 1, padding: 16, border: `1px solid ${form.role === 'teacher' ? 'var(--text-primary)' : 'var(--border)'}`,
                                    borderRadius: 'var(--radius-sm)', cursor: 'pointer', textAlign: 'center', transition: 'var(--transition)',
                                    background: form.role === 'teacher' ? 'var(--bg-secondary)' : 'transparent',
                                    boxShadow: form.role === 'teacher' ? '0 0 0 1px var(--text-primary)' : 'none'
                                }}
                                onClick={() => update('role', 'teacher')}
                            >
                                <FiMonitor size={24} style={{ marginBottom: 8, color: form.role === 'teacher' ? 'var(--text-primary)' : 'var(--text-muted)' }} />
                                <div style={{ fontSize: 13, fontWeight: 500 }}>Professeur</div>
                            </div>
                            <div
                                style={{
                                    flex: 1, padding: 16, border: `1px solid ${form.role === 'student' ? 'var(--text-primary)' : 'var(--border)'}`,
                                    borderRadius: 'var(--radius-sm)', cursor: 'pointer', textAlign: 'center', transition: 'var(--transition)',
                                    background: form.role === 'student' ? 'var(--bg-secondary)' : 'transparent',
                                    boxShadow: form.role === 'student' ? '0 0 0 1px var(--text-primary)' : 'none'
                                }}
                                onClick={() => update('role', 'student')}
                            >
                                <FiBookOpen size={24} style={{ marginBottom: 8, color: form.role === 'student' ? 'var(--text-primary)' : 'var(--text-muted)' }} />
                                <div style={{ fontSize: 13, fontWeight: 500 }}>Étudiant</div>
                            </div>
                        </div>
                    </div>

                    {/* Name */}
                    <div className="form-row">
                        <div className="form-group">
                            <label className="form-label">Prénom</label>
                            <input
                                type="text"
                                className={`form-input ${errors.first_name ? 'error' : ''}`}
                                placeholder="Jean"
                                value={form.first_name}
                                onChange={e => update('first_name', e.target.value)}
                                required
                            />
                            {errors.first_name && <div className="form-error">{errors.first_name}</div>}
                        </div>
                        <div className="form-group">
                            <label className="form-label">Nom</label>
                            <input
                                type="text"
                                className={`form-input ${errors.last_name ? 'error' : ''}`}
                                placeholder="Dupont"
                                value={form.last_name}
                                onChange={e => update('last_name', e.target.value)}
                                required
                            />
                        </div>
                    </div>

                    {/* Email */}
                    <div className="form-group">
                        <label className="form-label">Email</label>
                        <input
                            type="email"
                            className={`form-input ${errors.email ? 'error' : ''}`}
                            placeholder="vous@universite.edu"
                            value={form.email}
                            onChange={e => update('email', e.target.value)}
                            required
                        />
                        {errors.email && <div className="form-error">{errors.email}</div>}
                    </div>

                    {/* Password */}
                    <div className="form-group">
                        <label className="form-label">Mot de passe</label>
                        <input
                            type="password"
                            className={`form-input ${errors.password ? 'error' : ''}`}
                            placeholder="Min 8 caractères"
                            value={form.password}
                            onChange={e => update('password', e.target.value)}
                            required
                        />
                        {form.password && (
                            <div className="password-strength" style={{ marginTop: 8 }}>
                                <div className="password-strength-bar" style={{ height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
                                    <div
                                        className={`password-strength-fill ${strength.color}`}
                                        style={{ width: `${strength.pct}%`, height: '100%', transition: 'all 0.3s ease' }}
                                    />
                                </div>
                                <div className={`password-strength-text ${strength.color}`} style={{ fontSize: 11, marginTop: 4, fontWeight: 500 }}>
                                    {strength.label}
                                </div>
                            </div>
                        )}
                        {errors.password && <div className="form-error">{errors.password}</div>}
                    </div>

                    {/* Confirm Password */}
                    <div className="form-group">
                        <label className="form-label">Confirmer le mot de passe</label>
                        <input
                            type="password"
                            className={`form-input ${passwordsMismatch ? 'error' : ''}`}
                            placeholder="Répétez votre mot de passe"
                            value={form.confirmPassword}
                            onChange={e => update('confirmPassword', e.target.value)}
                            required
                        />
                        {passwordsMatch && <div className="form-error" style={{ color: 'var(--success)' }}>✓ Les mots de passe correspondent</div>}
                        {passwordsMismatch && <div className="form-error">✗ Les mots de passe ne correspondent pas</div>}
                        {errors.confirmPassword && <div className="form-error">{errors.confirmPassword}</div>}
                    </div>

                    <button type="submit" className="btn btn-primary btn-full btn-lg" style={{ marginTop: 12 }} disabled={loading || passwordsMismatch}>
                        {loading ? 'Création en cours...' : 'Créer un compte'}
                    </button>
                </form>

                <div className="auth-footer" style={{ textAlign: 'center', marginTop: 32, fontSize: 14, color: 'var(--text-secondary)' }}>
                    Vous avez déjà un compte ? <Link to="/login" style={{ fontWeight: 500, color: 'var(--text-primary)' }}>Se connecter</Link>
                </div>
            </motion.div>
        </div>
    );
}
