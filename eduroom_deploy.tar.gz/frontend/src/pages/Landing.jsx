import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiLayout, FiUploadCloud, FiClock, FiCheckSquare, FiMessageSquare, FiBell, FiArrowRight, FiBookOpen } from 'react-icons/fi';

const features = [
    { icon: <FiLayout />, title: 'Salles Magnifiques', desc: 'Couleurs personnalisées, mode sombre — des classes qui inspirent.' },
    { icon: <FiUploadCloud />, title: 'Glisser-Déposer', desc: 'Téléversez des cours, TP et ressources en quelques secondes.' },
    { icon: <FiClock />, title: 'Délais Intelligents', desc: 'Comptes à rebours, suivi des retards, rappels automatiques.' },
    { icon: <FiCheckSquare />, title: 'Correction Instantanée', desc: 'Notez les soumissions avec des retours en un clic.' },
    { icon: <FiMessageSquare />, title: 'Annonces', desc: 'Publiez des annonces avec commentaires et fils de discussion.' },
    { icon: <FiBell />, title: 'Notifications', desc: 'Alertes en temps réel pour les devoirs, les notes et plus.' },
];

export default function Landing() {
    return (
        <div>
            <nav className="landing-nav">
                <div className="brand">
                    <div className="logo" style={{
                        width: 32, height: 32,
                        background: 'var(--text-primary)', color: 'var(--bg-primary)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        borderRadius: 6, fontWeight: 500, fontFamily: 'var(--font-serif)'
                    }}>K</div>
                    <h1>Kelebia Classroom</h1>
                </div>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <Link to="/login" className="btn btn-ghost">Se connecter</Link>
                    <Link to="/signup" className="btn btn-primary">Démarrer</Link>
                </div>
            </nav>

            <section className="landing-hero">
                <motion.h1
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                >
                    La salle de classe,<br />Réinventée.
                </motion.h1>
                <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
                >
                    Une plateforme moderne conçue pour les universités. Créez des salles, partagez du contenu, collectez des devoirs et notez — le tout dans une interface élégante et épurée.
                </motion.p>
                <motion.div
                    className="actions"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                    style={{ display: 'flex', gap: 16, justifyContent: 'center' }}
                >
                    <Link to="/signup" className="btn btn-primary btn-lg">
                        Commencer à Enseigner <FiArrowRight />
                    </Link>
                    <Link to="/signup" className="btn btn-secondary btn-lg">
                        <FiBookOpen /> Rejoindre en tant qu'Étudiant
                    </Link>
                </motion.div>
            </section>

            <section style={{ borderTop: '1px solid var(--border)' }}>
                <div style={{ textAlign: 'center', padding: '96px 32px 0' }}>
                    <h2 style={{ fontSize: 36, fontWeight: 400, letterSpacing: '-0.5px' }}>
                        Conçu pour la <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, color: 'var(--brand)' }}>Concentration</span>
                    </h2>
                    <p style={{ color: 'var(--text-secondary)', marginTop: 16, fontSize: 16, maxWidth: 600, margin: '16px auto 0' }}>
                        Tout ce que vous souhaitiez que les systèmes d'apprentissage standards fassent, conçu avec une attention méticuleuse aux détails.
                    </p>
                </div>
                <div className="features-grid">
                    {features.map((f, i) => (
                        <motion.div
                            key={i}
                            className="feature-card"
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, margin: '-100px' }}
                            transition={{ duration: 0.6, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                        >
                            <div className="icon" style={{ fontSize: 24, marginBottom: 20, color: 'var(--text-primary)' }}>{f.icon}</div>
                            <h3 style={{ fontSize: 20, marginBottom: 12, fontFamily: 'var(--font-serif)', fontWeight: 500 }}>{f.title}</h3>
                            <p style={{ color: 'var(--text-secondary)', fontSize: 15, lineHeight: 1.6 }}>{f.desc}</p>
                        </motion.div>
                    ))}
                </div>
            </section>

            <footer className="landing-footer" style={{ padding: '64px 32px' }}>
                <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div className="logo" style={{
                            width: 24, height: 24,
                            background: 'var(--text-muted)', color: 'var(--bg-primary)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            borderRadius: 4, fontWeight: 500, fontFamily: 'var(--font-serif)', fontSize: 12
                        }}>K</div>
                        <span style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, color: 'var(--text-primary)' }}>Kelebia Classroom</span>
                    </div>
                    <p style={{ margin: 0 }}>Conçu avec une ingénierie de précision par Aymen HM</p>
                </div>
            </footer>
        </div>
    );
}
