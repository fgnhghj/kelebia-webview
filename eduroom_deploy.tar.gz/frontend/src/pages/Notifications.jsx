import { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import { notificationsAPI } from '../api';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { FiEdit3, FiFileText, FiAward, FiMessageSquare, FiMessageCircle, FiClock, FiHome, FiBell, FiCheck } from 'react-icons/fi';

const TYPE_ICONS = {
    assignment: <FiEdit3 />,
    submission: <FiFileText />,
    grade: <FiAward />,
    announcement: <FiMessageSquare />,
    comment: <FiMessageCircle />,
    deadline: <FiClock />,
    room: <FiHome />,
};

function timeAgo(d) {
    const s = Math.floor((Date.now() - new Date(d)) / 1000);
    if (s < 60) return 'à l\'instant';
    if (s < 3600) return `il y a ${Math.floor(s / 60)}m`;
    if (s < 86400) return `il y a ${Math.floor(s / 3600)}h`;
    return `il y a ${Math.floor(s / 86400)}j`;
}

export default function Notifications() {
    const [notifs, setNotifs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => { load(); }, []);

    const load = async () => {
        try {
            const { data } = await notificationsAPI.list();
            setNotifs(data.results || data);
        } catch { toast.error('Échec du chargement des notifications.'); }
        finally { setLoading(false); }
    };

    const markRead = async (id) => {
        await notificationsAPI.read(id);
        setNotifs(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    };

    const markAll = async () => {
        await notificationsAPI.readAll();
        setNotifs(prev => prev.map(n => ({ ...n, is_read: true })));
        toast.success('Tout a été marqué comme lu.');
    };

    return (
        <div className="app-layout">
            <Sidebar />
            <main className="main-content">
                <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                    <div>
                        <h1>Notifications</h1>
                        <p>Restez informé de tout ce qui se passe dans vos classes</p>
                    </div>
                    {notifs.some(n => !n.is_read) && (
                        <button className="btn btn-secondary btn-sm" onClick={markAll}>
                            <FiCheck style={{ marginRight: 6 }} /> Tout marquer comme lu
                        </button>
                    )}
                </div>

                {loading ? (
                    <div className="card"><div className="skeleton" style={{ height: 200 }} /></div>
                ) : notifs.length === 0 ? (
                    <div className="empty-state">
                        <div className="icon" style={{ fontSize: 40, color: 'var(--brand)', marginBottom: 16 }}>
                            <FiBell />
                        </div>
                        <h3>Aucune notification</h3>
                        <p>Vous êtes à jour !</p>
                    </div>
                ) : (
                    <div className="card card-flat" style={{ padding: 0, overflow: 'hidden' }}>
                        {notifs.map((n, i) => (
                            <motion.div
                                key={n.id}
                                className={`notif-item ${!n.is_read ? 'unread' : ''}`}
                                onClick={() => !n.is_read && markRead(n.id)}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.03 }}
                            >
                                <div className="notif-icon" style={{ color: !n.is_read ? 'var(--brand)' : 'var(--text-muted)' }}>
                                    {TYPE_ICONS[n.notification_type] || <FiBell />}
                                </div>
                                <div className="notif-body">
                                    <div className="title" style={{ fontFamily: 'var(--font-serif)', fontSize: 16 }}>{n.title}</div>
                                    <div className="message">{n.message}</div>
                                    <div className="time">{timeAgo(n.created_at)}</div>
                                </div>
                                {!n.is_read && <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--brand)' }} />}
                            </motion.div>
                        ))}
                    </div>
                )}
            </main>
        </div>
    );
}
