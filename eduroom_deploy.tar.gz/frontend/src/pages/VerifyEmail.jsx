import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { authAPI } from '../api';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { FiMail, FiCheck, FiRefreshCw } from 'react-icons/fi';

export default function VerifyEmail() {
    const { user, refreshUser } = useAuth();
    const navigate = useNavigate();
    const [code, setCode] = useState('');
    const [loading, setLoading] = useState(false);
    const [resending, setResending] = useState(false);

    if (user?.email_verified) {
        navigate('/dashboard');
        return null;
    }

    const handleVerify = async (e) => {
        e.preventDefault();
        if (code.length !== 6) {
            toast.error('Veuillez entrer un code à 6 chiffres.');
            return;
        }
        setLoading(true);
        try {
            await authAPI.verifyEmail(code);
            toast.success('Email vérifié avec succès !');
            if (refreshUser) await refreshUser();
            navigate('/dashboard');
        } catch (err) {
            toast.error(err.response?.data?.detail || 'Code invalide.');
        }
        setLoading(false);
    };

    const handleResend = async () => {
        setResending(true);
        try {
            await authAPI.resendVerification();
            toast.success('Code renvoyé à votre email.');
        } catch (err) {
            toast.error(err.response?.data?.detail || 'Erreur lors de l\'envoi.');
        }
        setResending(false);
    };

    return (
        <div className="auth-page">
            <motion.div className="auth-card" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <div style={{ textAlign: 'center', marginBottom: 32 }}>
                    <div style={{
                        width: 64, height: 64, borderRadius: '50%',
                        background: 'var(--brand-bg)', display: 'flex',
                        alignItems: 'center', justifyContent: 'center',
                        margin: '0 auto 16px', color: 'var(--brand)', fontSize: 28
                    }}>
                        <FiMail />
                    </div>
                    <h1 style={{ fontSize: 24, fontWeight: 700 }}>Vérification de l'email</h1>
                    <p style={{ color: 'var(--text-muted)', marginTop: 8 }}>
                        Un code à 6 chiffres a été envoyé à <strong>{user?.email}</strong>
                    </p>
                </div>

                <form onSubmit={handleVerify}>
                    <div className="form-group">
                        <label className="form-label">Code de vérification</label>
                        <input
                            className="form-input"
                            type="text"
                            maxLength={6}
                            placeholder="000000"
                            value={code}
                            onChange={e => setCode(e.target.value.replace(/\D/g, ''))}
                            style={{
                                textAlign: 'center', fontSize: 28, letterSpacing: '8px',
                                fontWeight: 700, fontFamily: 'monospace'
                            }}
                            autoFocus
                            required
                        />
                    </div>

                    <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: 16 }} disabled={loading}>
                        {loading ? 'Vérification...' : <><FiCheck style={{ marginRight: 6 }} /> Vérifier</>}
                    </button>
                </form>

                <div style={{ textAlign: 'center', marginTop: 24 }}>
                    <button
                        onClick={handleResend}
                        className="btn btn-ghost"
                        disabled={resending}
                        style={{ fontSize: 14 }}
                    >
                        <FiRefreshCw style={{ marginRight: 6 }} />
                        {resending ? 'Envoi en cours...' : 'Renvoyer le code'}
                    </button>
                </div>

                <p style={{ textAlign: 'center', marginTop: 16, fontSize: 13, color: 'var(--text-muted)' }}>
                    Vérifiez également votre dossier spam.
                </p>
            </motion.div>
        </div>
    );
}
