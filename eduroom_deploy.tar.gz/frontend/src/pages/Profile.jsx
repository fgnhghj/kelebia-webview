import { useState } from 'react';
import { useAuth } from '../AuthContext';
import Sidebar from '../components/Sidebar';
import toast from 'react-hot-toast';
import { authAPI } from '../api';
import { motion } from 'framer-motion';
import { FiShield, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';

export default function Profile() {
    const { user, refreshUser } = useAuth();
    const [form, setForm] = useState({
        first_name: user?.first_name || '',
        last_name: user?.last_name || '',
        bio: user?.bio || '',
        institution: user?.institution || '',
    });
    const [loading, setLoading] = useState(false);

    // 2FA state
    const [twoFaStep, setTwoFaStep] = useState(null);
    const [qrData, setQrData] = useState(null);
    const [totpCode, setTotpCode] = useState('');
    const [twoFaLoading, setTwoFaLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const fd = new FormData();
            Object.entries(form).forEach(([k, v]) => fd.append(k, v));
            await authAPI.updateProfile(fd);
            await refreshUser();
            toast.success('Profil mis \u00e0 jour !');
        } catch {
            toast.error('\u00c9chec de la mise \u00e0 jour du profil.');
        }
        setLoading(false);
    };

    const handleEnable2FA = async () => {
        setTwoFaLoading(true);
        try {
            const { data } = await authAPI.enable2FA();
            setQrData(data);
            setTwoFaStep('setup');
        } catch (err) {
            toast.error(err.response?.data?.detail || 'Erreur.');
        }
        setTwoFaLoading(false);
    };

    const handleConfirm2FA = async () => {
        setTwoFaLoading(true);
        try {
            await authAPI.confirm2FA(totpCode);
            toast.success('2FA activ\u00e9 !');
            setTwoFaStep(null);
            setQrData(null);
            setTotpCode('');
            await refreshUser();
        } catch (err) {
            toast.error(err.response?.data?.detail || 'Code invalide.');
        }
        setTwoFaLoading(false);
    };

    const handleDisable2FA = async () => {
        if (!window.confirm('\u00cates-vous s\u00fbr de vouloir d\u00e9sactiver la 2FA ?')) return;
        setTwoFaLoading(true);
        try {
            await authAPI.disable2FA();
            toast.success('2FA d\u00e9sactiv\u00e9.');
            await refreshUser();
        } catch {
            toast.error('Erreur.');
        }
        setTwoFaLoading(false);
    };

    return (
        <div className="app-layout">
            <Sidebar />
            <main className="main-content">
                <div className="page-header">
                    <h1>Profil</h1>
                    <p>G\u00e9rez les param\u00e8tres de votre compte</p>
                </div>

                <motion.div className="card" style={{ maxWidth: 560 }} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
                        <div className="avatar xl">
                            {(user?.first_name?.[0] || 'U').toUpperCase()}
                        </div>
                        <div>
                            <h2 style={{ fontWeight: 700, fontSize: 20 }}>{user?.full_name || user?.username}</h2>
                            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{user?.email}</p>
                            <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                                <span className="badge badge-brand">{user?.role === 'teacher' ? 'Professeur' : '\u00c9tudiant'}</span>
                                {user?.email_verified ? (
                                    <span className="badge badge-success" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><FiCheckCircle /> Email v\u00e9rifi\u00e9</span>
                                ) : (
                                    <span className="badge badge-warning" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><FiAlertCircle /> Non v\u00e9rifi\u00e9</span>
                                )}
                            </div>
                        </div>
                    </div>

                    <form onSubmit={handleSubmit}>
                        <div className="form-row">
                            <div className="form-group">
                                <label className="form-label">Pr\u00e9nom</label>
                                <input className="form-input" value={form.first_name} onChange={e => setForm(p => ({ ...p, first_name: e.target.value }))} />
                            </div>
                            <div className="form-group">
                                <label className="form-label">Nom de famille</label>
                                <input className="form-input" value={form.last_name} onChange={e => setForm(p => ({ ...p, last_name: e.target.value }))} />
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="form-label">Biographie</label>
                            <textarea className="form-input" rows="3" placeholder="Parlez-nous de vous..." value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Institution</label>
                            <input className="form-input" placeholder="ex: Universit\u00e9 des Sciences" value={form.institution} onChange={e => setForm(p => ({ ...p, institution: e.target.value }))} />
                        </div>

                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? 'Enregistrement...' : 'Enregistrer les modifications'}
                        </button>
                    </form>
                </motion.div>

                {/* 2FA Section */}
                <motion.div className="card" style={{ maxWidth: 560, marginTop: 24 }} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
                        <FiShield size={22} />
                        <div>
                            <h3 style={{ fontWeight: 700, fontSize: 16 }}>Authentification \u00e0 deux facteurs (2FA)</h3>
                            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                                {user?.is_2fa_enabled ? 'La 2FA est activ\u00e9e pour votre compte.' : 'Ajoutez une couche de s\u00e9curit\u00e9 suppl\u00e9mentaire.'}
                            </p>
                        </div>
                    </div>

                    {user?.is_2fa_enabled ? (
                        <div>
                            <div className="badge badge-success" style={{ marginBottom: 16, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                                <FiCheckCircle /> 2FA activ\u00e9
                            </div>
                            <br />
                            <button className="btn btn-secondary btn-sm" onClick={handleDisable2FA} disabled={twoFaLoading}>
                                {twoFaLoading ? 'D\u00e9sactivation...' : 'D\u00e9sactiver la 2FA'}
                            </button>
                        </div>
                    ) : twoFaStep === 'setup' ? (
                        <div>
                            <p style={{ fontSize: 14, marginBottom: 16 }}>
                                Scannez ce QR code avec votre application d'authentification (Google Authenticator, Authy, etc.)
                            </p>
                            {qrData?.qr_code && (
                                <div style={{ textAlign: 'center', marginBottom: 16 }}>
                                    <img src={qrData.qr_code} alt="2FA QR Code" style={{ width: 200, height: 200, borderRadius: 8, border: '1px solid var(--border)' }} />
                                </div>
                            )}
                            <div className="form-group">
                                <label className="form-label">Code de v\u00e9rification</label>
                                <input
                                    type="text" className="form-input" placeholder="000000" maxLength={6}
                                    value={totpCode} onChange={e => setTotpCode(e.target.value.replace(/\D/g, ''))}
                                    style={{ textAlign: 'center', fontSize: 20, letterSpacing: '6px', fontWeight: 700, fontFamily: 'monospace' }}
                                />
                            </div>
                            <div style={{ display: 'flex', gap: 8 }}>
                                <button className="btn btn-primary btn-sm" onClick={handleConfirm2FA} disabled={twoFaLoading || totpCode.length !== 6}>
                                    {twoFaLoading ? 'V\u00e9rification...' : 'Confirmer'}
                                </button>
                                <button className="btn btn-secondary btn-sm" onClick={() => { setTwoFaStep(null); setTotpCode(''); }}>Annuler</button>
                            </div>
                        </div>
                    ) : (
                        <button className="btn btn-primary btn-sm" onClick={handleEnable2FA} disabled={twoFaLoading}>
                            {twoFaLoading ? 'Chargement...' : 'Activer la 2FA'}
                        </button>
                    )}
                </motion.div>
            </main>
        </div>
    );
}
