import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import Sidebar from '../components/Sidebar';
import { roomsAPI } from '../api';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { FiPlus, FiLink, FiUsers, FiBookOpen, FiTrash2, FiLogOut } from 'react-icons/fi';

const COLORS = [
    '#3A4B54', '#5C504A', '#485E5A', '#605068',
    '#4A5468', '#684A4A', '#52584C', '#4A5F68',
    '#68554A', '#2D2D2D'
];

export default function Dashboard() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [rooms, setRooms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showCreate, setShowCreate] = useState(false);
    const [showJoin, setShowJoin] = useState(false);
    const [createForm, setCreateForm] = useState({ name: '', subject: '', description: '', color_theme: '#3A4B54' });
    const [joinCode, setJoinCode] = useState('');
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        loadRooms();
    }, []);

    const loadRooms = async () => {
        try {
            const { data } = await roomsAPI.list();
            setRooms(data.results || data);
        } catch { toast.error('Échec du chargement des salles.'); }
        finally { setLoading(false); }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const fd = new FormData();
            Object.entries(createForm).forEach(([k, v]) => { if (v) fd.append(k, v); });
            const { data } = await roomsAPI.create(fd);
            toast.success('Salle créée !');
            setShowCreate(false);
            setCreateForm({ name: '', subject: '', description: '', color_theme: '#3A4B54' });
            navigate(`/rooms/${data.id}`);
        } catch (err) {
            toast.error(err.response?.data?.name?.[0] || 'Échec de la création de la salle.');
        }
        setSubmitting(false);
    };

    const handleJoin = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const { data } = await roomsAPI.join(joinCode);
            toast.success(data.message);
            setShowJoin(false);
            setJoinCode('');
            navigate(`/rooms/${data.room.id}`);
        } catch (err) {
            toast.error(err.response?.data?.error || 'Code d\'invitation invalide.');
        }
        setSubmitting(false);
    };

    const handleDelete = async (e, id) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm("Êtes-vous sûr de vouloir supprimer cette salle ?")) {
            try {
                await roomsAPI.delete(id);
                toast.success('Salle supprimée');
                loadRooms();
            } catch { toast.error('Erreur lors de la suppression'); }
        }
    };

    const handleLeave = async (e, id) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm("Êtes-vous sûr de vouloir quitter cette salle ?")) {
            try {
                await roomsAPI.leave(id);
                toast.success('Vous avez quitté la salle');
                loadRooms();
            } catch { toast.error('Erreur lors de la sortie'); }
        }
    };

    return (
        <div className="app-layout">
            <Sidebar />
            <main className="main-content">
                <div className="page-header">
                    <h1>Bienvenue, {user?.first_name || 'là-bas'}</h1>
                    <p>{user?.role === 'teacher' ? 'Gérez vos classes et vos devoirs' : 'Vos classes inscrites'}</p>
                    <div className="page-header-actions">
                        {user?.role === 'teacher' && (
                            <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
                                <FiPlus style={{ marginRight: 6 }} /> Créer une salle
                            </button>
                        )}
                        <button className="btn btn-secondary" onClick={() => setShowJoin(true)}>
                            <FiLink style={{ marginRight: 6 }} /> Rejoindre une salle
                        </button>
                    </div>
                </div>

                {/* Stats */}
                <div className="stats-grid">
                    <div className="stat-card">
                        <div className="stat-value">{rooms.length}</div>
                        <div className="stat-label">{user?.role === 'teacher' ? 'Vos Salles' : 'Salles Inscrites'}</div>
                    </div>
                </div>

                {/* Room Grid */}
                {loading ? (
                    <div className="room-grid">
                        {[1, 2, 3].map(i => (
                            <div key={i} className="card"><div className="skeleton" style={{ height: 100, marginBottom: 12 }} /><div className="skeleton" style={{ height: 20, width: '60%' }} /></div>
                        ))}
                    </div>
                ) : rooms.length === 0 ? (
                    <div className="empty-state">
                        <div className="icon" style={{ fontSize: 40, color: 'var(--brand)', marginBottom: 16 }}>
                            <FiBookOpen />
                        </div>
                        <h3>{user?.role === 'teacher' ? 'Aucune salle pour le moment' : 'Vous n\'êtes inscrit à aucune salle'}</h3>
                        <p>{user?.role === 'teacher' ? 'Créez votre première classe pour commencer.' : 'Rejoignez une salle en utilisant un code d\'invitation de votre professeur.'}</p>
                    </div>
                ) : (
                    <div className="room-grid">
                        {rooms.map((room, i) => (
                            <motion.div
                                key={room.id}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.05 }}
                            >
                                <Link to={`/rooms/${room.id}`} className="room-card" style={{ textDecoration: 'none', color: 'inherit' }}>
                                    <div className="room-card-banner" style={{ background: `linear-gradient(135deg, ${room.color_theme}, ${room.color_theme}88)`, position: 'relative' }}>
                                        <h3>{room.name}</h3>
                                        {user?.role === 'teacher' ? (
                                            <button onClick={(e) => handleDelete(e, room.id)} className="btn btn-ghost btn-icon btn-sm" style={{ position: 'absolute', top: 12, right: 12, color: 'white' }} title="Supprimer la salle">
                                                <FiTrash2 />
                                            </button>
                                        ) : (
                                            <button onClick={(e) => handleLeave(e, room.id)} className="btn btn-ghost btn-icon btn-sm" style={{ position: 'absolute', top: 12, right: 12, color: 'white' }} title="Quitter la salle">
                                                <FiLogOut />
                                            </button>
                                        )}
                                    </div>
                                    <div className="room-card-body">
                                        <p>{room.subject || room.description || 'Pas de description'}</p>
                                        <div className="room-card-meta">
                                            <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                                <FiUsers /> {room.student_count} étudiants
                                            </span>
                                            {user?.role === 'teacher' && <span className="badge badge-brand">Professeur</span>}
                                        </div>
                                    </div>
                                </Link>
                            </motion.div>
                        ))}
                    </div>
                )}

                {/* Create Room Modal */}
                {showCreate && (
                    <div className="modal-overlay" onClick={() => setShowCreate(false)}>
                        <motion.div className="modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                            <div className="modal-header">
                                <h2>Créer une salle</h2>
                                <button className="btn btn-ghost btn-icon" onClick={() => setShowCreate(false)}>✕</button>
                            </div>
                            <form onSubmit={handleCreate}>
                                <div className="modal-body">
                                    <div className="form-group">
                                        <label className="form-label">Nom de la salle *</label>
                                        <input className="form-input" placeholder="ex: Informatique 101" value={createForm.name} onChange={e => setCreateForm(p => ({ ...p, name: e.target.value }))} required autoFocus />
                                    </div>
                                    <div className="form-group">
                                        <label className="form-label">Matière</label>
                                        <input className="form-input" placeholder="ex: Informatique" value={createForm.subject} onChange={e => setCreateForm(p => ({ ...p, subject: e.target.value }))} />
                                    </div>
                                    <div className="form-group">
                                        <label className="form-label">Description</label>
                                        <textarea className="form-input" rows="2" placeholder="Brève description..." value={createForm.description} onChange={e => setCreateForm(p => ({ ...p, description: e.target.value }))} />
                                    </div>
                                    <div className="form-group">
                                        <label className="form-label">Thème de couleur</label>
                                        <div className="color-options">
                                            {COLORS.map(c => (
                                                <div key={c} className={`color-swatch ${createForm.color_theme === c ? 'selected' : ''}`} style={{ background: c }} onClick={() => setCreateForm(p => ({ ...p, color_theme: c }))} />
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowCreate(false)}>Annuler</button>
                                    <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Création...' : 'Créer la salle'}</button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}

                {/* Join Room Modal */}
                {showJoin && (
                    <div className="modal-overlay" onClick={() => setShowJoin(false)}>
                        <motion.div className="modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                            <div className="modal-header">
                                <h2>Rejoindre une salle</h2>
                                <button className="btn btn-ghost btn-icon" onClick={() => setShowJoin(false)}>✕</button>
                            </div>
                            <form onSubmit={handleJoin}>
                                <div className="modal-body">
                                    <div className="form-group">
                                        <label className="form-label">Code d'invitation</label>
                                        <input className="form-input" placeholder="Saisissez le code à 8 caractères" value={joinCode} onChange={e => setJoinCode(e.target.value.toUpperCase())} maxLength={8} required autoFocus style={{ letterSpacing: '2px', fontWeight: 600, textAlign: 'center', fontSize: 18 }} />
                                    </div>
                                    <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Demandez le code d'invitation de la salle à votre professeur.</p>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowJoin(false)}>Annuler</button>
                                    <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Connexion...' : 'Rejoindre la salle'}</button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </main>
        </div>
    );
}
