import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import Sidebar from '../components/Sidebar';
import { roomsAPI, sectionsAPI, contentAPI, assignmentsAPI, submissionsAPI, announcementsAPI, commentsAPI } from '../api';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import {
    FiFileText, FiActivity, FiEdit3, FiPackage, FiLink, FiCopy,
    FiClock, FiFile, FiEdit, FiMessageSquare, FiUsers, FiPaperclip,
    FiFolderPlus, FiFolder, FiDownload, FiExternalLink, FiPlus,
    FiCheckCircle, FiAward, FiMapPin, FiMessageCircle,
    FiCheck, FiX, FiTrash2, FiBookOpen
} from 'react-icons/fi';

const TYPE_ICONS = {
    lecture: <FiFileText />,
    tp: <FiActivity />,
    exam: <FiEdit3 />,
    resource: <FiPackage />,
    link: <FiLink />
};

function copyToClipboard(text) {
    navigator.clipboard.writeText(text);
    toast.success('Code copié !');
}

function timeAgo(d) {
    const s = Math.floor((Date.now() - new Date(d)) / 1000);
    if (s < 60) return 'à l\'instant';
    if (s < 3600) return `il y a ${Math.floor(s / 60)}m`;
    if (s < 86400) return `il y a ${Math.floor(s / 3600)}h`;
    return `il y a ${Math.floor(s / 86400)}j`;
}

function Countdown({ deadline }) {
    const [diff, setDiff] = useState(new Date(deadline) - Date.now());
    useEffect(() => {
        const t = setInterval(() => setDiff(new Date(deadline) - Date.now()), 1000);
        return () => clearInterval(t);
    }, [deadline]);
    if (diff <= 0) return <span className="badge badge-danger" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><FiClock /> Date limite dépassée</span>;
    const d = Math.floor(diff / 86400000), h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000), sec = Math.floor((diff % 60000) / 1000);
    return (
        <div className="countdown">
            <div className="countdown-unit"><div className="value">{d}</div><div className="label">Jours</div></div>
            <div className="countdown-unit"><div className="value">{h}</div><div className="label">Hrs</div></div>
            <div className="countdown-unit"><div className="value">{m}</div><div className="label">Min</div></div>
            <div className="countdown-unit"><div className="value">{sec}</div><div className="label">Sec</div></div>
        </div>
    );
}

export default function RoomDetail() {
    const { id } = useParams();
    const { user } = useAuth();
    const [room, setRoom] = useState(null);
    const [tab, setTab] = useState('contenu');
    const [sections, setSections] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [announcements, setAnnouncements] = useState([]);
    const [members, setMembers] = useState({ members: [], pending: [] });
    const [loading, setLoading] = useState(true);

    // Modals
    const [showUpload, setShowUpload] = useState(false);
    const [showAssignment, setShowAssignment] = useState(false);
    const [showAnnouncement, setShowAnnouncement] = useState(false);
    const [showSection, setShowSection] = useState(false);

    // Forms
    const [uploadForm, setUploadForm] = useState({ title: '', section: '', content_type: 'lecture', file: null, link: '' });
    const [assignForm, setAssignForm] = useState({ title: '', description: '', deadline: '', max_grade: 20, section: '' });
    const [announceForm, setAnnounceForm] = useState({ title: '', body: '' });
    const [sectionTitle, setSectionTitle] = useState('');
    const [submitting, setSubmitting] = useState(false);

    // Feature States
    const [selectedFiles, setSelectedFiles] = useState({});
    const [selectedMembers, setSelectedMembers] = useState([]);

    const isTeacher = room?.teacher?.id === user?.id;

    useEffect(() => { loadAll(); }, [id]);

    const loadAll = async () => {
        try {
            const [roomRes, secRes, assRes, annRes] = await Promise.all([
                roomsAPI.get(id), sectionsAPI.list(id), assignmentsAPI.list(id), announcementsAPI.list(id)
            ]);
            setRoom(roomRes.data);
            setSections(secRes.data.results || secRes.data);
            setAssignments(assRes.data.results || assRes.data);
            setAnnouncements(annRes.data.results || annRes.data);
            if (roomRes.data.teacher?.id === user?.id) {
                const memRes = await roomsAPI.members(id);
                setMembers(memRes.data);
            }
        } catch { toast.error('Échec du chargement de la salle.'); }
        finally { setLoading(false); }
    };

    const handleUpload = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const fd = new FormData();
            fd.append('room', id);
            fd.append('title', uploadForm.title);
            fd.append('content_type', uploadForm.content_type);
            if (uploadForm.section) fd.append('section', uploadForm.section);
            if (uploadForm.file) fd.append('file', uploadForm.file);
            if (uploadForm.link) fd.append('link', uploadForm.link);
            await contentAPI.create(fd);
            toast.success('Contenu téléversé !');
            setShowUpload(false);
            setUploadForm({ title: '', section: '', content_type: 'lecture', file: null, link: '' });
            loadAll();
        } catch { toast.error('Échec du téléversement.'); }
        setSubmitting(false);
    };

    const handleNewAssignment = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const fd = new FormData();
            fd.append('room', id);
            fd.append('title', assignForm.title);
            fd.append('description', assignForm.description);
            if (assignForm.deadline) fd.append('deadline', new Date(assignForm.deadline).toISOString());
            fd.append('max_grade', assignForm.max_grade);
            if (assignForm.section) fd.append('section', assignForm.section);
            await assignmentsAPI.create(fd);
            toast.success('Devoir créé !');
            setShowAssignment(false);
            setAssignForm({ title: '', description: '', deadline: '', max_grade: 20, section: '' });
            loadAll();
        } catch { toast.error('Échec de la création du devoir.'); }
        setSubmitting(false);
    };

    const handleNewAnnouncement = async (e) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            await announcementsAPI.create({ room: parseInt(id), ...announceForm });
            toast.success('Annonce publiée !');
            setShowAnnouncement(false);
            setAnnounceForm({ title: '', body: '' });
            loadAll();
        } catch { toast.error('Échec de la publication.'); }
        setSubmitting(false);
    };

    const handleNewSection = async (e) => {
        e.preventDefault();
        if (!sectionTitle.trim()) return;
        try {
            await sectionsAPI.create({ room: parseInt(id), title: sectionTitle });
            toast.success('Section ajoutée !');
            setShowSection(false);
            setSectionTitle('');
            loadAll();
        } catch { toast.error('Échec.'); }
    };

    const handleMultiSubmit = async (assignmentId) => {
        const files = selectedFiles[assignmentId];
        if (!files || files.length === 0) return;
        setSubmitting(true);
        const fd = new FormData();
        fd.append('assignment', assignmentId);
        files.forEach(f => fd.append('files', f));
        try {
            await submissionsAPI.create(fd);
            toast.success('Soumis avec succès !');
            setSelectedFiles(p => { const newP = { ...p }; delete newP[assignmentId]; return newP; });
            loadAll();
        } catch (err) {
            toast.error(err.response?.data?.non_field_errors?.[0] || 'Échec de la soumission.');
        }
        setSubmitting(false);
    };

    const handleMemberAction = async (memberId, action) => {
        try {
            await roomsAPI.manageMember(id, { member_ids: [memberId], action });
            toast.success(action === 'approve' ? 'Approuvé !' : 'Supprimé !');
            const memRes = await roomsAPI.members(id);
            setMembers(memRes.data);
            setSelectedMembers(p => p.filter(x => x !== memberId));
        } catch { toast.error('Échec de l\'opération.'); }
    };

    const handleBulkRemove = async () => {
        if (!window.confirm(`Expulser ${selectedMembers.length} étudiant(s) ?`)) return;
        try {
            await roomsAPI.manageMember(id, { member_ids: selectedMembers, action: 'remove' });
            toast.success(`Étudiants expulsés !`);
            setSelectedMembers([]);
            const memRes = await roomsAPI.members(id);
            setMembers(memRes.data);
        } catch { toast.error('Échec de l\'opération.'); }
    };

    if (loading) return (
        <div className="app-layout"><Sidebar /><main className="main-content">
            <div className="skeleton" style={{ height: 120, marginBottom: 20, borderRadius: 'var(--radius-md)' }} />
            <div className="skeleton" style={{ height: 40, width: '50%', marginBottom: 20 }} />
            <div className="skeleton" style={{ height: 200 }} />
        </main></div>
    );

    if (!room) return <div className="app-layout"><Sidebar /><main className="main-content"><div className="empty-state"><h3>Salle non trouvée</h3></div></main></div>;

    return (
        <div className="app-layout">
            <Sidebar />
            <main className="main-content">
                {/* Banner */}
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{
                    background: `linear-gradient(135deg, ${room.color_theme}, ${room.color_theme}88)`,
                    borderRadius: 'var(--radius-lg)', padding: '28px 24px', marginBottom: 24, color: 'white'
                }}>
                    <div style={{ fontSize: 13, opacity: 0.8, marginBottom: 8, fontWeight: 500 }}>
                        <Link to="/dashboard" style={{ color: 'white', textDecoration: 'none' }}>Tableau de bord</Link> / {room.name}
                    </div>
                    <h1 style={{ fontSize: 32, fontWeight: 800, marginBottom: 8, letterSpacing: '-0.5px' }}>{room.name}</h1>
                    {room.subject && <span className="badge" style={{ background: 'rgba(255,255,255,0.2)', color: 'white', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.1)' }}>{room.subject}</span>}

                    {isTeacher && (
                        <div style={{ marginTop: 24 }}>
                            <div className="invite-code-container" style={{
                                background: 'rgba(0,0,0,0.2)',
                                backdropFilter: 'blur(8px)',
                                borderRadius: '8px',
                                display: 'inline-flex',
                                alignItems: 'center',
                                padding: '8px 16px',
                                gap: 16,
                                border: '1px solid rgba(255,255,255,0.1)'
                            }}>
                                <div style={{ display: 'flex', flexDirection: 'column' }}>
                                    <span style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.5px', opacity: 0.7 }}>Code d'invitation</span>
                                    <span style={{ color: 'white', fontWeight: 600, letterSpacing: '1px', fontSize: 15, fontFamily: 'monospace' }}>{room.invite_code}</span>
                                </div>
                                <button
                                    onClick={() => copyToClipboard(room.invite_code)}
                                    style={{
                                        background: 'rgba(255,255,255,0.1)', color: 'white',
                                        border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px',
                                        padding: '6px 14px', fontSize: 13, fontWeight: 500,
                                        display: 'flex', alignItems: 'center', gap: 6,
                                        cursor: 'pointer', transition: 'all 0.2s',
                                        gridColumn: 'auto'
                                    }}
                                    onMouseOver={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.2)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.3)'; }}
                                    onMouseOut={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.1)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.2)'; }}
                                >
                                    <FiCopy size={14} /> Copier
                                </button>
                            </div>
                        </div>
                    )}
                </motion.div>

                {/* Tabs */}
                <div className="tabs">
                    {['contenu', 'devoirs', 'annonces', ...(isTeacher ? ['membres'] : [])].map(t => (
                        <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>
                            {t === 'contenu' && <FiFile style={{ marginRight: 6 }} />}
                            {t === 'devoirs' && <FiEdit style={{ marginRight: 6 }} />}
                            {t === 'annonces' && <FiMessageSquare style={{ marginRight: 6 }} />}
                            {t === 'membres' && <FiUsers style={{ marginRight: 6 }} />}
                            {t.charAt(0).toUpperCase() + t.slice(1)}
                        </button>
                    ))}
                </div>

                {/* Content Tab */}
                {tab === 'contenu' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                        {isTeacher && (
                            <div style={{ marginBottom: 16, display: 'flex', gap: 8 }}>
                                <button className="btn btn-primary btn-sm" onClick={() => setShowUpload(true)}>
                                    <FiPaperclip style={{ marginRight: 6 }} /> Ajouter du contenu
                                </button>
                                <button className="btn btn-secondary btn-sm" onClick={() => setShowSection(true)}>
                                    <FiFolderPlus style={{ marginRight: 6 }} /> Nouvelle section
                                </button>
                            </div>
                        )}
                        {sections.length === 0 ? (
                            <div className="empty-state">
                                <div className="icon" style={{ fontSize: 40, color: 'var(--brand)', marginBottom: 16 }}>
                                    <FiFile />
                                </div>
                                <h3>Aucun contenu pour le moment</h3>
                            </div>
                        ) : sections.map(sec => (
                            <div key={sec.id} className="section-block">
                                <div className="section-header">
                                    <h3 style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                        <FiFolder color="var(--brand)" /> {sec.title}
                                    </h3>
                                </div>
                                <div className="content-list">
                                    {sec.contents?.length === 0 ? (
                                        <p style={{ fontSize: 13, color: 'var(--text-muted)', padding: '8px 0' }}>Aucun contenu dans cette section.</p>
                                    ) : sec.contents?.map(item => (
                                        <div key={item.id} className="content-item">
                                            <div className="item-icon" style={{ background: 'var(--brand-bg)', color: 'var(--brand)' }}>
                                                {TYPE_ICONS[item.content_type] || <FiPackage />}
                                            </div>
                                            <div className="item-info">
                                                <h4>{item.title}</h4>
                                                <p>{item.content_type} · {new Date(item.created_at).toLocaleDateString()}{item.file_size_display ? ` · ${item.file_size_display}` : ''}</p>
                                            </div>
                                            <div className="item-actions">
                                                {item.file && <a href={item.file} className="btn btn-primary btn-sm btn-icon" download><FiDownload /></a>}
                                                {item.link && <a href={item.link} className="btn btn-secondary btn-sm btn-icon" target="_blank" rel="noreferrer"><FiExternalLink /></a>}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </motion.div>
                )}

                {/* Assignments Tab */}
                {tab === 'devoirs' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                        {isTeacher && (
                            <div style={{ marginBottom: 16 }}>
                                <button className="btn btn-primary btn-sm" onClick={() => setShowAssignment(true)}>
                                    <FiPlus style={{ marginRight: 6 }} /> Nouveau devoir
                                </button>
                            </div>
                        )}
                        {assignments.length === 0 ? (
                            <div className="empty-state">
                                <div className="icon" style={{ fontSize: 40, color: 'var(--brand)', marginBottom: 16 }}>
                                    <FiEdit />
                                </div>
                                <h3>Aucun devoir pour le moment</h3>
                            </div>
                        ) : assignments.map(a => (
                            <div key={a.id} className="card" style={{ marginBottom: 12 }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: 12 }}>
                                    <div>
                                        <h4 style={{ fontWeight: 700, fontSize: 16 }}>{a.title}</h4>
                                        {a.description && <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>{a.description}</p>}
                                    </div>
                                    {a.deadline && (
                                        a.is_past_deadline
                                            ? <span className="badge badge-danger" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><FiClock /> En retard</span>
                                            : <span className="badge badge-warning" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><FiClock /> {new Date(a.deadline).toLocaleDateString()}</span>
                                    )}
                                </div>
                                {a.deadline && !a.is_past_deadline && <div style={{ marginTop: 12 }}><Countdown deadline={a.deadline} /></div>}

                                <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap', alignItems: 'center' }}>
                                    <span className="badge badge-info">Max: {a.max_grade} pts</span>
                                    {isTeacher && <span className="badge badge-brand">{a.submissions_count || 0} soumissions</span>}
                                    {isTeacher && a.unsubmitted_count > 0 && (
                                        <span className="badge badge-danger" style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                                            <div style={{ width: 6, height: 6, background: 'currentColor', borderRadius: '50%' }} />
                                            {a.unsubmitted_count} non soumis
                                        </span>
                                    )}
                                    {a.my_submission && (
                                        <span className={`badge ${a.my_submission.is_late ? 'badge-warning' : 'badge-success'}`} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                                            {a.my_submission.is_late ? <><FiClock /> En retard</> : <><FiCheckCircle /> Soumis</>}
                                        </span>
                                    )}
                                    {a.my_submission?.grade && (
                                        <span className="badge badge-success" style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                                            <FiAward /> {a.my_submission.grade.score}/{a.max_grade}
                                        </span>
                                    )}
                                </div>

                                {a.my_submission && a.my_submission.files && a.my_submission.files.length > 0 && (
                                    <div style={{ marginTop: 12, padding: '12px', background: 'var(--bg-secondary)', borderRadius: '6px' }}>
                                        <h5 style={{ fontSize: 11, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 8, fontWeight: 700 }}>Fichiers soumis :</h5>
                                        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                                            {a.my_submission.files.map(f => (
                                                <a key={f.id} href={f.file} target="_blank" rel="noreferrer" style={{ fontSize: 13, color: 'var(--brand)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 6 }}>
                                                    <FiFileText size={14} /> {f.filename}
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {!isTeacher && !a.my_submission && (
                                    <div style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
                                        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                                            <label className="btn btn-secondary btn-sm" style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                                                <FiPaperclip /> Joindre des fichiers
                                                <input type="file" multiple hidden onChange={e => {
                                                    if (e.target.files.length) {
                                                        setSelectedFiles(p => ({ ...p, [a.id]: [...(p[a.id] || []), ...Array.from(e.target.files)] }));
                                                    }
                                                }} />
                                            </label>

                                            {selectedFiles[a.id] && selectedFiles[a.id].length > 0 && (
                                                <div style={{ flex: 1 }}>
                                                    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 12 }}>
                                                        {selectedFiles[a.id].map((f, i) => (
                                                            <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-secondary)', padding: '6px 12px', borderRadius: 4, fontSize: 13 }}>
                                                                <span style={{ display: 'flex', alignItems: 'center', gap: 6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}><FiFile size={14} /> {f.name}</span>
                                                                <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setSelectedFiles(p => ({ ...p, [a.id]: p[a.id].filter((_, idx) => idx !== i) }))}>
                                                                    <FiX />
                                                                </button>
                                                            </div>
                                                        ))}
                                                    </div>
                                                    <button className="btn btn-primary btn-sm" disabled={submitting} onClick={() => handleMultiSubmit(a.id)}>
                                                        {submitting ? 'Envoi...' : `Envoyer le devoir (${selectedFiles[a.id].length} fichier${selectedFiles[a.id].length > 1 ? 's' : ''})`}
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </motion.div>
                )}

                {/* Announcements Tab */}
                {tab === 'annonces' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                        {isTeacher && (
                            <div style={{ marginBottom: 16 }}>
                                <button className="btn btn-primary btn-sm" onClick={() => setShowAnnouncement(true)}>
                                    <FiMessageSquare style={{ marginRight: 6 }} /> Nouvelle annonce
                                </button>
                            </div>
                        )}
                        {announcements.length === 0 ? (
                            <div className="empty-state">
                                <div className="icon" style={{ fontSize: 40, color: 'var(--brand)', marginBottom: 16 }}>
                                    <FiMessageSquare />
                                </div>
                                <h3>Aucune annonce pour le moment</h3>
                            </div>
                        ) : announcements.map(a => (
                            <div key={a.id} className="announcement-item">
                                <div className="announcement-header">
                                    <div className="avatar sm">{(a.author?.first_name?.[0] || '?').toUpperCase()}</div>
                                    <div className="meta">
                                        <div className="name">{a.author?.full_name || a.author?.username}</div>
                                        <div className="time">{timeAgo(a.created_at)}</div>
                                    </div>
                                    {a.is_pinned && <span className="badge badge-brand" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><FiMapPin size={12} /> Épinglée</span>}
                                </div>
                                <h4 style={{ fontWeight: 700, marginBottom: 4 }}>{a.title}</h4>
                                <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{a.body}</p>
                                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
                                    <FiMessageCircle /> {a.comment_count || 0} commentaires
                                </p>
                            </div>
                        ))}
                    </motion.div>
                )}

                {/* Members Tab (Teacher Only) */}
                {tab === 'membres' && isTeacher && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                        <h3 style={{ fontWeight: 700, marginBottom: 16 }}>Membres ({members.members?.length || 0})</h3>
                        {members.pending?.length > 0 && (
                            <div className="card" style={{ marginBottom: 16, borderColor: 'var(--warning)', borderWidth: 1, borderStyle: 'solid' }}>
                                <h4 style={{ marginBottom: 16, color: 'var(--warning)', display: 'flex', alignItems: 'center', gap: 8 }}>
                                    <FiClock /> Demandes en attente ({members.pending.length})
                                </h4>
                                {members.pending.map(m => (
                                    <div key={m.id} className="member-item">
                                        <div className="avatar sm">{(m.student?.first_name?.[0] || '?').toUpperCase()}</div>
                                        <div className="member-info">
                                            <div className="name">{m.student?.full_name}</div>
                                            <div className="email">{m.student?.email}</div>
                                        </div>
                                        <div style={{ display: 'flex', gap: 6 }}>
                                            <button className="btn btn-primary btn-sm btn-icon" onClick={() => handleMemberAction(m.id, 'approve')} title="Approuver">
                                                <FiCheck />
                                            </button>
                                            <button className="btn btn-danger btn-sm btn-icon" onClick={() => handleMemberAction(m.id, 'remove')} title="Rejeter">
                                                <FiX />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                            {selectedMembers.length > 0 && (
                                <div style={{ padding: '12px 16px', background: 'var(--brand-bg)', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--brand)' }}>{selectedMembers.length} étudiant(s) sélectionné(s)</span>
                                    <button className="btn btn-danger btn-sm" onClick={handleBulkRemove}>
                                        <FiTrash2 style={{ marginRight: 6 }} /> Expulser la sélection
                                    </button>
                                </div>
                            )}
                            {members.members?.map((m, idx) => (
                                <div key={m.id} className={`member-item ${selectedMembers.includes(m.id) ? 'selected' : ''}`} style={{ borderBottom: idx === members.members.length - 1 ? 'none' : '1px solid var(--border)', transition: 'background 0.2s' }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedMembers.includes(m.id)}
                                        onChange={() => {
                                            setSelectedMembers(p => p.includes(m.id) ? p.filter(id => id !== m.id) : [...p, m.id]);
                                        }}
                                        style={{ marginRight: 12, cursor: 'pointer', accentColor: 'var(--brand)' }}
                                    />
                                    <div className="avatar sm">{(m.student?.first_name?.[0] || '?').toUpperCase()}</div>
                                    <div className="member-info">
                                        <div className="name">{m.student?.full_name || m.student?.username}</div>
                                        <div className="email">{m.student?.email}</div>
                                    </div>
                                </div>
                            ))}
                            {members.members?.length === 0 && (
                                <div className="empty-state" style={{ padding: '40px 20px' }}>
                                    <div className="icon" style={{ fontSize: 32, color: 'var(--text-muted)', marginBottom: 12 }}>
                                        <FiUsers />
                                    </div>
                                    <h3>Aucun membre pour le moment</h3>
                                    <p>Partagez le code d'invitation avec vos étudiants.</p>
                                </div>
                            )}
                        </div>
                    </motion.div>
                )}

                {/* === MODALS === */}

                {/* Upload Content Modal */}
                {showUpload && (
                    <div className="modal-overlay" onClick={() => setShowUpload(false)}>
                        <motion.div className="modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                            <div className="modal-header">
                                <h2>Ajouter du contenu</h2>
                                <button className="btn btn-ghost btn-icon" onClick={() => setShowUpload(false)}><FiX /></button>
                            </div>
                            <form onSubmit={handleUpload}>
                                <div className="modal-body">
                                    <div className="form-group">
                                        <label className="form-label">Titre *</label>
                                        <input className="form-input" value={uploadForm.title} onChange={e => setUploadForm(p => ({ ...p, title: e.target.value }))} required autoFocus />
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group">
                                            <label className="form-label">Type</label>
                                            <select className="form-input" value={uploadForm.content_type} onChange={e => setUploadForm(p => ({ ...p, content_type: e.target.value }))}>
                                                <option value="lecture">Cours</option><option value="tp">TP</option><option value="exam">Examen</option><option value="resource">Ressource</option><option value="link">Lien</option>
                                            </select>
                                        </div>
                                        <div className="form-group">
                                            <label className="form-label">Section</label>
                                            <select className="form-input" value={uploadForm.section} onChange={e => setUploadForm(p => ({ ...p, section: e.target.value }))}>
                                                <option value="">Aucune</option>
                                                {sections.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                                            </select>
                                        </div>
                                    </div>
                                    {uploadForm.content_type === 'link' ? (
                                        <div className="form-group">
                                            <label className="form-label">URL</label>
                                            <input className="form-input" type="url" placeholder="https://..." value={uploadForm.link} onChange={e => setUploadForm(p => ({ ...p, link: e.target.value }))} />
                                        </div>
                                    ) : (
                                        <div className="form-group">
                                            <label className="form-label">Fichier</label>
                                            <div className="file-drop" onClick={() => document.getElementById('file-input').click()} onDragOver={e => { e.preventDefault(); e.currentTarget.classList.add('dragover'); }} onDragLeave={e => e.currentTarget.classList.remove('dragover')} onDrop={e => { e.preventDefault(); e.currentTarget.classList.remove('dragover'); if (e.dataTransfer.files[0]) setUploadForm(p => ({ ...p, file: e.dataTransfer.files[0] })); }}>
                                                <div className="icon" style={{ fontSize: 32, marginBottom: 8, color: 'var(--brand)' }}>
                                                    <FiPaperclip />
                                                </div>
                                                <p style={{ fontWeight: 600 }}>{uploadForm.file ? uploadForm.file.name : 'Cliquez ou glissez un fichier ici'}</p>
                                                <div className="hint">Maximum 50 Mo</div>
                                            </div>
                                            <input id="file-input" type="file" hidden onChange={e => e.target.files[0] && setUploadForm(p => ({ ...p, file: e.target.files[0] }))} />
                                        </div>
                                    )}
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowUpload(false)}>Annuler</button>
                                    <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Envoi...' : 'Ajouter'}</button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}

                {/* New Assignment Modal */}
                {showAssignment && (
                    <div className="modal-overlay" onClick={() => setShowAssignment(false)}>
                        <motion.div className="modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                            <div className="modal-header">
                                <h2>Nouveau devoir</h2>
                                <button className="btn btn-ghost btn-icon" onClick={() => setShowAssignment(false)}><FiX /></button>
                            </div>
                            <form onSubmit={handleNewAssignment}>
                                <div className="modal-body">
                                    <div className="form-group"><label className="form-label">Titre *</label><input className="form-input" value={assignForm.title} onChange={e => setAssignForm(p => ({ ...p, title: e.target.value }))} required autoFocus /></div>
                                    <div className="form-group"><label className="form-label">Description</label><textarea className="form-input" rows="3" value={assignForm.description} onChange={e => setAssignForm(p => ({ ...p, description: e.target.value }))} /></div>
                                    <div className="form-row">
                                        <div className="form-group"><label className="form-label">Date limite</label><input className="form-input" type="datetime-local" value={assignForm.deadline} onChange={e => setAssignForm(p => ({ ...p, deadline: e.target.value }))} /></div>
                                        <div className="form-group"><label className="form-label">Note maximale</label><input className="form-input" type="number" min="1" value={assignForm.max_grade} onChange={e => setAssignForm(p => ({ ...p, max_grade: e.target.value }))} /></div>
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowAssignment(false)}>Annuler</button>
                                    <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Création...' : 'Créer le devoir'}</button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}

                {/* New Announcement Modal */}
                {showAnnouncement && (
                    <div className="modal-overlay" onClick={() => setShowAnnouncement(false)}>
                        <motion.div className="modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                            <div className="modal-header">
                                <h2>Publier une annonce</h2>
                                <button className="btn btn-ghost btn-icon" onClick={() => setShowAnnouncement(false)}><FiX /></button>
                            </div>
                            <form onSubmit={handleNewAnnouncement}>
                                <div className="modal-body">
                                    <div className="form-group"><label className="form-label">Titre *</label><input className="form-input" value={announceForm.title} onChange={e => setAnnounceForm(p => ({ ...p, title: e.target.value }))} required autoFocus /></div>
                                    <div className="form-group"><label className="form-label">Message *</label><textarea className="form-input" rows="4" value={announceForm.body} onChange={e => setAnnounceForm(p => ({ ...p, body: e.target.value }))} required /></div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowAnnouncement(false)}>Annuler</button>
                                    <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Publication...' : 'Publier'}</button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}

                {/* Add Section Modal */}
                {showSection && (
                    <div className="modal-overlay" onClick={() => setShowSection(false)}>
                        <motion.div className="modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                            <div className="modal-header">
                                <h2>Ajouter une section</h2>
                                <button className="btn btn-ghost btn-icon" onClick={() => setShowSection(false)}><FiX /></button>
                            </div>
                            <form onSubmit={handleNewSection}>
                                <div className="modal-body">
                                    <div className="form-group"><label className="form-label">Nom de la section *</label><input className="form-input" value={sectionTitle} onChange={e => setSectionTitle(e.target.value)} placeholder="ex: Semaine 1, Chapitre 3" required autoFocus /></div>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setShowSection(false)}>Annuler</button>
                                    <button type="submit" className="btn btn-primary">Ajouter</button>
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </main>
        </div>
    );
}
