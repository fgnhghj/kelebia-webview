import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '';

const api = axios.create({
    baseURL: `${API_BASE}/api`,
    headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Auto-refresh on 401
api.interceptors.response.use(
    (res) => res,
    async (error) => {
        const original = error.config;
        if (error.response?.status === 401 && !original._retry) {
            original._retry = true;
            const refresh = localStorage.getItem('refresh_token');
            if (refresh) {
                try {
                    const { data } = await axios.post(`${API_BASE}/api/auth/token/refresh/`, { refresh });
                    localStorage.setItem('access_token', data.access);
                    original.headers.Authorization = `Bearer ${data.access}`;
                    return api(original);
                } catch {
                    localStorage.removeItem('access_token');
                    localStorage.removeItem('refresh_token');
                    window.location.href = '/login';
                }
            }
        }
        return Promise.reject(error);
    }
);

// Auth
export const authAPI = {
    signup: (data) => api.post('/auth/signup/', data),
    login: (data) => api.post('/auth/login/', data),
    me: () => api.get('/auth/me/'),
    updateProfile: (data) => api.patch('/auth/me/', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
    verifyEmail: (code) => api.post('/auth/verify-email/', { code }),
    resendVerification: () => api.post('/auth/resend-verification/'),
    enable2FA: () => api.post('/auth/2fa/enable/'),
    confirm2FA: (code) => api.post('/auth/2fa/confirm/', { code }),
    disable2FA: () => api.post('/auth/2fa/disable/'),
};

// Rooms
export const roomsAPI = {
    list: () => api.get('/rooms/'),
    get: (id) => api.get(`/rooms/${id}/`),
    create: (data) => api.post('/rooms/', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
    update: (id, data) => api.patch(`/rooms/${id}/`, data, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
    delete: (id) => api.delete(`/rooms/${id}/`),
    join: (code) => api.post('/rooms/join/', { invite_code: code }),
    leave: (id) => api.post(`/rooms/${id}/leave/`),
    members: (id) => api.get(`/rooms/${id}/members/`),
    manageMember: (id, data) => api.post(`/rooms/${id}/manage_member/`, data),
};

// Sections
export const sectionsAPI = {
    list: (roomId) => api.get(`/sections/?room=${roomId}`),
    create: (data) => api.post('/sections/', data),
    update: (id, data) => api.patch(`/sections/${id}/`, data),
    delete: (id) => api.delete(`/sections/${id}/`),
};

// Content
export const contentAPI = {
    list: (roomId) => api.get(`/content/?room=${roomId}`),
    create: (data) => api.post('/content/', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
    delete: (id) => api.delete(`/content/${id}/`),
};

// Assignments
export const assignmentsAPI = {
    list: (roomId) => api.get(`/assignments/?room=${roomId}`),
    get: (id) => api.get(`/assignments/${id}/`),
    create: (data) => api.post('/assignments/', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
    delete: (id) => api.delete(`/assignments/${id}/`),
};

// Submissions
export const submissionsAPI = {
    list: (assignmentId) => api.get(`/submissions/?assignment=${assignmentId}`),
    create: (data) => api.post('/submissions/', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
};

// Announcements
export const announcementsAPI = {
    list: (roomId) => api.get(`/announcements/?room=${roomId}`),
    get: (id) => api.get(`/announcements/${id}/`),
    create: (data) => api.post('/announcements/', data),
    delete: (id) => api.delete(`/announcements/${id}/`),
};

// Comments
export const commentsAPI = {
    list: (announcementId) => api.get(`/comments/?announcement=${announcementId}`),
    create: (data) => api.post('/comments/', data),
};

// Notifications
export const notificationsAPI = {
    list: () => api.get('/notifications/'),
    read: (id) => api.post(`/notifications/${id}/read/`),
    readAll: () => api.post('/notifications/read_all/'),
    unreadCount: () => api.get('/notifications/unread_count/'),
};

export default api;
