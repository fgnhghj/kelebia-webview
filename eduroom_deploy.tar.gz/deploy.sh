#!/bin/bash
# ================================================
# Kelebia Classroom — Server Deployment Script
# Deploy to: 13.60.253.1 (user: ubuntu)
# ================================================

set -e

PROJECT_DIR="/home/ubuntu/eduroom"
VENV_DIR="$PROJECT_DIR/venv"

echo ""
echo "=============================="
echo "  Kelebia Classroom Deploy"
echo "=============================="

# --- 1. System packages ---
echo "[1/9] Installing system packages..."
sudo apt update -qq
sudo apt install -y -qq python3 python3-pip python3-venv python3-dev \
    postgresql postgresql-contrib nginx libpq-dev build-essential curl

# Install Node.js for React build
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y -qq nodejs
fi

# --- 2. PostgreSQL ---
echo "[2/9] Setting up PostgreSQL..."
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='eduroom_user'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE ROLE eduroom_user WITH LOGIN PASSWORD 'eduroom_secure_pass_2026';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='eduroom'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE DATABASE eduroom OWNER eduroom_user;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE eduroom TO eduroom_user;"

# --- 3. Project directory ---
echo "[3/9] Setting up project directory..."
sudo mkdir -p $PROJECT_DIR
sudo chown -R ubuntu:ubuntu $PROJECT_DIR

# --- 4. Virtual environment ---
echo "[4/9] Setting up Python virtual environment..."
python3 -m venv $VENV_DIR || true
$VENV_DIR/bin/pip install --upgrade pip -q
$VENV_DIR/bin/pip install -r $PROJECT_DIR/requirements.txt -q

# --- 5. Environment variables ---
echo "[5/9] Configuring environment..."
GENERATED_SECRET_KEY=$($VENV_DIR/bin/python3 -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())')
cat > $PROJECT_DIR/.env << EOF
DJANGO_SECRET_KEY="$GENERATED_SECRET_KEY"
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=13.60.253.1,localhost,kelebia.com
DATABASE_URL=postgres
DB_NAME=eduroom
DB_USER=eduroom_user
DB_PASSWORD=eduroom_secure_pass_2026
DB_HOST=localhost
DB_PORT=5432
EOF
set -a && source $PROJECT_DIR/.env && set +a

# --- 6. Build React frontend ---
echo "[6/9] Building React frontend..."
cd $PROJECT_DIR/frontend
npm install --production=false -q 2>&1 | tail -1
npm run build
cd $PROJECT_DIR

# --- 7. Django setup ---
echo "[7/9] Running Django setup..."
$VENV_DIR/bin/python manage.py migrate --noinput
$VENV_DIR/bin/python manage.py collectstatic --noinput
echo "from accounts.models import User; User.objects.filter(username='admin').exists() or User.objects.create_superuser('admin', 'admin@kelebia.com', 'admin123')" | $VENV_DIR/bin/python manage.py shell

# --- 8. Gunicorn service ---
echo "[8/9] Setting up Gunicorn service..."
sudo tee /etc/systemd/system/kelebia.service > /dev/null << EOF
[Unit]
Description=Kelebia Classroom Gunicorn Daemon
After=network.target

[Service]
User=ubuntu
Group=www-data
WorkingDirectory=$PROJECT_DIR
EnvironmentFile=$PROJECT_DIR/.env
ExecStart=$VENV_DIR/bin/gunicorn eduroom.wsgi:application --bind 127.0.0.1:8000 --workers 3 --timeout 120

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable kelebia
sudo systemctl restart kelebia

# --- 9. Nginx ---
echo "[9/9] Configuring Nginx..."

# Serve the React SPA from the collected static files
sudo tee /etc/nginx/sites-available/kelebia > /dev/null << 'NGINX'
server {
    listen 80;
    server_name 13.60.253.1;

    client_max_body_size 50M;

    # API endpoints — proxy to Django/Gunicorn
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Django admin
    location /admin/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Django static files (admin CSS etc)
    location /static/ {
        alias /home/ubuntu/eduroom/staticfiles/;
    }

    # Media uploads
    location /media/ {
        alias /home/ubuntu/eduroom/media/;
    }

    # React SPA — serve index.html for all non-API routes
    location / {
        root /home/ubuntu/eduroom/frontend/dist;
        try_files $uri $uri/ /index.html;
    }
}
NGINX

sudo rm -f /etc/nginx/sites-enabled/default
sudo rm -f /etc/nginx/sites-enabled/eduroom
sudo rm -f /etc/nginx/sites-enabled/kelebia
sudo ln -s /etc/nginx/sites-available/kelebia /etc/nginx/sites-enabled/kelebia
sudo nginx -t
sudo systemctl restart nginx

# Fix permissions
sudo chown -R ubuntu:www-data $PROJECT_DIR/staticfiles $PROJECT_DIR/static
sudo chmod -R 755 /home/ubuntu /home/ubuntu/eduroom $PROJECT_DIR/staticfiles $PROJECT_DIR/static
sudo mkdir -p $PROJECT_DIR/media
sudo chown -R ubuntu:www-data $PROJECT_DIR/media
sudo chmod -R 755 $PROJECT_DIR/media

echo ""
echo "=============================="
echo "  ✅ Kelebia Classroom deployed!"
echo "  Visit: http://13.60.253.1"
echo "=============================="
